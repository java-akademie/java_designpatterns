package ch.jmildner.designpattern.mvcs;

import javax.swing.*;
import java.awt.event.*;

public class ViewPanel extends JPanel
{
	JTextField betrag = new JTextField("1", 5);
	JTextField saldo = new JTextField("0", 10);

	JButton add = new JButton("+");
	JButton sub = new JButton("-");
	JButton quit1 = new JButton("quit1");
	JButton quit2 = new JButton("quit2");

	public ViewPanel()
	{
		makeTheLayout();
		addTheListener();
		makeMvcVerbindung();
	}

	private void makeTheLayout()
	{
		JPanel n = new JPanel();
		JPanel s = new JPanel();
		n.add(betrag);
		n.add(add);
		n.add(sub);
		n.add(saldo);
		s.add(quit1);
		s.add(quit2);
		add(n);
		add(s);
	}

	private void addTheListener()
	{
		quit1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				System.out.println("" + "q1 verarbeitung in panel");
				System.exit(0);
			}
		});
	}

	private void makeMvcVerbindung()
	{
		Model model = new Model(betrag);
		ModelObserver modelObserver = new ModelObserver(saldo);
		Controller controller = new Controller(model);

		add.addActionListener(controller);
		sub.addActionListener(controller);
		quit2.addActionListener(controller);

		model.addObserver(modelObserver);
		model.setSaldo(0);
	}
}
