package ch.jmildner.designpattern.mvcs;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class ViewFrame extends JFrame
{
	public ViewFrame()
	{
		super("mvc");

		Container cont = getContentPane();
		cont.add(new ViewPanel());

		setLocation(200, 100);
		pack();
		show();

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
	}

	public static void main(String[] args)
	{
		new ViewFrame();
	}
}
