package ch.jmildner.designpattern.mvcs;

import javax.swing.*;
import java.awt.*;

public class ViewApplet extends JApplet
{

	public void init()
	{
		Container cont = getContentPane();
		cont.add(new ViewPanel());
	}
}
